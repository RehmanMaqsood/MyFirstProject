<?php
/*
Theme Name: Breeze
Description: Breeze e-commerce theme is created to make impression on you and your customers.
Author: InfoStyle
Author URI: http://themeforest.net/user/InfoStyle
Version: 1.0
License: ThemeForest Regular & Extended License
License URI: http://themeforest.net/licenses/regular_extended
*/

add_action('wp_enqueue_scripts', 'breeze_jscss');
function breeze_jscss() {
    wp_enqueue_style('jquery-ui', 'http://code.jquery.com/ui/1.10.1/themes/overcast/jquery-ui.min.css');
    wp_enqueue_style('breeze', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('jqzoom', get_template_directory_uri() . '/css/jquery.jqzoom.css');

    wp_register_script( 'carouFredSel', get_template_directory_uri() . '/js/jquery.carouFredSel-6.2.0-packed.js', array(), '6.2.0', true);
    wp_register_script( 'touchSwipe', get_template_directory_uri() . '/js/jquery.touchSwipe.min.js', array(), '1.3.3', true);
    wp_register_script( 'jqzoom', get_template_directory_uri() . '/js/jquery.jqzoom-core.js', array(), '2.3', true);
    wp_register_script( 'checkbox', get_template_directory_uri() . '/js/checkbox.js', array(), false, true);
    wp_register_script( 'radio', get_template_directory_uri() . '/js/radio.js', array(), false, true);

    wp_enqueue_script( 'breeze', get_template_directory_uri() . '/js/main.js', array('jquery', 'jquery-ui-core', 'carouFredSel', 'touchSwipe', 'jqzoom', 'checkbox', 'radio'), false, true);
}

add_action( 'wp_head', 'wps_add_ie_html5_shim' );
function wps_add_ie_html5_shim() {
    global $is_IE;
    if ( $is_IE ) {
        echo '<!--[if lt IE 9]>';
        echo '<script src="' . get_template_directory_uri() . '/js/html5.js" type="text/javascript"></script>
              <script src="' . get_template_directory_uri() . '/js/PIE_IE6789.js" type="text/javascript"></script>';
        echo '<![endif]-->';
    }
}

// Load main options panel file
require_once (TEMPLATEPATH . '/inc/admin-menu.php');
require_once (TEMPLATEPATH . '/inc/colors.php');

add_theme_support( 'custom-header', array(
        'default-image' =>  get_template_directory_uri() . '/images/logo.png',
	'width'         => 228,
	'height'        => 70,
        'flex-width'    => true,
	'flex-height'   => true,
	'header-text'   => false,
) );

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) )
	$content_width = 980;

/**
 * Tell WordPress to run breeze_setup() when the 'after_setup_theme' hook is run.
 */
add_action( 'after_setup_theme', 'breeze_setup' );

if ( ! function_exists( 'breeze_setup' ) ):
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 *
 * To override breeze_setup() in a child theme, add your own breeze_setup to your child theme's
 * functions.php file.
 *
 * @uses load_theme_textdomain() For translation/localization support.
 * @uses add_editor_style() To style the visual editor.
 * @uses add_theme_support() To add support for post thumbnails, automatic feed links, custom headers
 * 	and backgrounds, and post formats.
 * @uses register_nav_menus() To add support for navigation menus.
 * @uses register_default_headers() To register the default custom header images provided with the theme.
 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
 *
 * @since Breeze
 */
function breeze_setup() {

	/* Make Breeze available for translation.
	 * Translations can be added to the /languages/ directory.
	 * If you're building a theme based on Breeze, use a find and replace
	 * to change 'breeze' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'breeze', get_template_directory() . '/languages' );

	// This theme styles the visual editor with editor-style.css to match the theme style.
	add_editor_style();

	// Add default posts and comments RSS feed links to <head>.
	add_theme_support( 'automatic-feed-links' );

	// This theme uses wp_nav_menu() in one location.
        register_nav_menu( 'private', __( 'Private Menu', 'breeze' ) );
	register_nav_menu( 'primary', __( 'Primary Menu', 'breeze' ) );
        register_nav_menu( 'information', __( 'Footer First Menu', 'breeze' ) );
        register_nav_menu( 'servise', __( 'Footer Second Menu', 'breeze' ) );
        register_nav_menu( 'my-account', __( 'Footer Third Menu', 'breeze' ) );

	// Add support for a variety of post formats
	add_theme_support( 'post-formats', array( 'aside', 'link', 'gallery', 'status', 'quote', 'image' ) );

	// This theme uses Featured Images (also known as post thumbnails) for per-post/per-page Custom Header images
	add_theme_support( 'post-thumbnails' );

	add_theme_support( 'woocommerce' );
}
endif; // breeze_setup

/**
 * Sets the post excerpt length to 40 words.
 *
 * To override this length in a child theme, remove the filter and add your own
 * function tied to the excerpt_length filter hook.
 */
function breeze_excerpt_length( $length ) {
	return 40;
}
add_filter( 'excerpt_length', 'breeze_excerpt_length' );

if ( ! function_exists( 'breeze_continue_reading_link' ) ) :
/**
 * Returns a "Continue Reading" link for excerpts
 */
function breeze_continue_reading_link() {
	return ' <a href="'. esc_url( get_permalink() ) . '">' . __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'breeze' ) . '</a>';
}
endif; // breeze_continue_reading_link


/**
 * Replaces "[...]" (appended to automatically generated excerpts) with an ellipsis and breeze_continue_reading_link().
 *
 * To override this in a child theme, remove the filter and add your own
 * function tied to the excerpt_more filter hook.
 */
function breeze_auto_excerpt_more( $more ) {
	return ' &hellip;' . breeze_continue_reading_link();
}
add_filter( 'excerpt_more', 'breeze_auto_excerpt_more' );

/**
 * Adds a pretty "Continue Reading" link to custom post excerpts.
 *
 * To override this link in a child theme, remove the filter and add your own
 * function tied to the get_the_excerpt filter hook.
 */
function breeze_custom_excerpt_more( $output ) {
	if ( has_excerpt() && ! is_attachment() ) {
		$output .= breeze_continue_reading_link();
	}
	return $output;
}
add_filter( 'get_the_excerpt', 'breeze_custom_excerpt_more' );

/**
 * Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link.
 */
function breeze_page_menu_args( $args ) {
	if ( ! isset( $args['show_home'] ) )
		$args['show_home'] = true;
	return $args;
}
add_filter( 'wp_page_menu_args', 'breeze_page_menu_args' );

/**
 * Register our sidebars and widgetized areas. Also register the default Epherma widget.
 *
 * @since Breeze
 */
function breeze_widgets_init() {
        
        register_sidebar( array(
		'name' => __( 'Main Sidebar', 'breeze' ),
		'id' => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
        
        register_sidebar( array(
		'name' => __( 'Sidebar Blog', 'breeze' ),
		'id' => 'sidebar-blog',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
        
        register_sidebar( array(
		'name' => __( 'Home First Column', 'breeze' ),
		'id' => 'bottom-block-1',
		'description' => __( 'An optional widget area for your site footer', 'breeze' ),
		'before_widget' => '<div class="bottom_block about_as">',
		'after_widget' => "</div>",
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	) );
        register_sidebar( array(
		'name' => __( 'Home Second Column', 'breeze' ),
		'id' => 'bottom-block-2',
		'description' => __( 'An optional widget area for your site footer', 'breeze' ),
		'before_widget' => '<div class="bottom_block news">',
		'after_widget' => "</div>",
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	) );
        register_sidebar( array(
		'name' => __( 'Home Third Column', 'breeze' ),
		'id' => 'bottom-block-3',
		'description' => __( 'An optional widget area for your site footer', 'breeze' ),
		'before_widget' => '<div class="bottom_block newsletter">',
		'after_widget' => "</div>",
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	) );

}
add_action( 'widgets_init', 'breeze_widgets_init' );

if ( ! function_exists( 'breeze_content_nav' ) ) :
/**
 * Display navigation to next/previous pages when applicable
 */
function breeze_content_nav( $html_id ) {
	global $wp_query;

	if ( $wp_query->max_num_pages > 1 ) : ?>
		<nav id="<?php echo esc_attr( $html_id ); ?>">
			<h3 class="assistive-text"><?php _e( 'Post navigation', 'breeze' ); ?></h3>
			<div class="nav-previous"><?php next_posts_link( __( '<span class="meta-nav">&larr;</span> Older posts', 'breeze' ) ); ?></div>
			<div class="nav-next"><?php previous_posts_link( __( 'Newer posts <span class="meta-nav">&rarr;</span>', 'breeze' ) ); ?></div>
		</nav><!-- #nav-above -->
	<?php endif;
}
endif; // breeze_content_nav

/**
 * Return the URL for the first link found in the post content.
 *
 * @since Breeze
 * @return string|bool URL or false when no link is present.
 */
function breeze_url_grabber() {
	if ( ! preg_match( '/<a\s[^>]*?href=[\'"](.+?)[\'"]/is', get_the_content(), $matches ) )
		return false;

	return esc_url_raw( $matches[1] );
}

/**
 * Count the number of footer sidebars to enable dynamic classes for the footer
 */
function breeze_footer_sidebar_class() {
	$count = 0;

	if ( is_active_sidebar( 'sidebar-3' ) )
		$count++;

	if ( is_active_sidebar( 'sidebar-4' ) )
		$count++;

	if ( is_active_sidebar( 'sidebar-5' ) )
		$count++;

	$class = '';

	switch ( $count ) {
		case '1':
			$class = 'one';
			break;
		case '2':
			$class = 'two';
			break;
		case '3':
			$class = 'three';
			break;
	}

	if ( $class )
		echo 'class="' . $class . '"';
}

if ( ! function_exists( 'breeze_comment' ) ) :
/**
 * Template for comments and pingbacks.
 *
 * To override this walker in a child theme without modifying the comments template
 * simply create your own breeze_comment(), and that function will be used instead.
 *
 * Used as a callback by wp_list_comments() for displaying the comments.
 *
 * @since Breeze
 */
function breeze_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :
	?>
	<li class="post pingback">
		<p><?php _e( 'Pingback:', 'breeze' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( __( 'Edit', 'breeze' ), '<span class="edit-link">', '</span>' ); ?></p>
	<?php
			break;
		default :
	?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<article id="comment-<?php comment_ID(); ?>" class="comment">
			<footer class="comment-meta">
				<div class="comment-author vcard">
					<?php
						$avatar_size = 68;
						if ( '0' != $comment->comment_parent )
							$avatar_size = 39;

						echo get_avatar( $comment, $avatar_size );

						/* translators: 1: comment author, 2: date and time */
						printf( __( '%1$s on %2$s <span class="says">said:</span>', 'breeze' ),
							sprintf( '<span class="fn">%s</span>', get_comment_author_link() ),
							sprintf( '<a href="%1$s"><time datetime="%2$s">%3$s</time></a>',
								esc_url( get_comment_link( $comment->comment_ID ) ),
								get_comment_time( 'c' ),
								/* translators: 1: date, 2: time */
								sprintf( __( '%1$s at %2$s', 'breeze' ), get_comment_date(), get_comment_time() )
							)
						);
					?>

					<?php edit_comment_link( __( 'Edit', 'breeze' ), '<span class="edit-link">', '</span>' ); ?>
				</div><!-- .comment-author .vcard -->

				<?php if ( $comment->comment_approved == '0' ) : ?>
					<em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'breeze' ); ?></em>
					<br />
				<?php endif; ?>

			</footer>

			<div class="comment-content"><?php comment_text(); ?></div>

			<div class="reply">
				<?php comment_reply_link( array_merge( $args, array( 'reply_text' => __( 'Reply <span>&darr;</span>', 'breeze' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
			</div><!-- .reply -->
		</article><!-- #comment-## -->

	<?php
			break;
	endswitch;
}
endif; // ends check for breeze_comment()

if ( ! function_exists( 'breeze_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 * Create your own breeze_posted_on to override in a child theme
 *
 * @since Breeze
 */
function breeze_posted_on() {
	printf( __( '<span class="sep">Posted on </span><a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date" datetime="%3$s">%4$s</time></a><span class="by-author"> <span class="sep"> by </span> <span class="author vcard"><a class="url fn n" href="%5$s" title="%6$s" rel="author">%7$s</a></span></span>', 'breeze' ),
		esc_url( get_permalink() ),
		esc_attr( get_the_time() ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
		esc_attr( sprintf( __( 'View all posts by %s', 'breeze' ), get_the_author() ) ),
		get_the_author()
	);
}
endif;

/**
 * Adds two classes to the array of body classes.
 * The first is if the site has only had one author with published posts.
 * The second is if a singular post being displayed
 *
 * @since Breeze
 */
function breeze_body_classes( $classes ) {

	if ( function_exists( 'is_multi_author' ) && ! is_multi_author() )
		$classes[] = 'single-author';

	if ( is_singular() && ! is_home() && ! is_page_template( 'showcase.php' ) && ! is_page_template( 'sidebar-page.php' ) )
		$classes[] = 'singular';

	return $classes;
}
add_filter( 'body_class', 'breeze_body_classes' );

define('WOOCOMMERCE_USE_CSS', false);

//Slides
add_action( 'init', 'slides_type' );
function slides_type() {
register_post_type( 'slides',
     array(
            'labels' => array(
            'name' => __( 'Slides', 'breeze' ),
            'singular_name' => __( 'Slide', 'breeze' ),
            'has_archive' => true,
            'add_new' => 'Add New Slide',
            'not_found' => 'No found.',
            'not_found_in_trash' => 'In the cart slides found'
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array(
                'title',
                'editor',
                'trackbacks',
                'thumbnail',
                'page-attributes',
            ),
           
       ));
}

if ( ! function_exists( 'query_post_type' ) ) :
add_filter('pre_get_posts', 'query_post_type');
function query_post_type($query) {

    $post_types = get_post_types();
    if ( is_category() || is_tag()) {

        $post_type = get_query_var('slides');

        if ( $post_type )
            $post_type = $post_type;
        else
            $post_type = $post_types;

        $query->set('post_type', $post_type);

    return $query;
    }
}
endif;

//Home Banners
add_action( 'init', 'home_banners_type' );
function home_banners_type() {
register_post_type( 'home_banners',
     array(
            'labels' => array(
            'name' => __( 'Home Banners', 'breeze' ),
            'singular_name' => __( 'Banner', 'breeze' ),
            'has_archive' => true,
            'add_new' => 'Add New Banner',
            'not_found' => 'No found.',
            'not_found_in_trash' => 'In the cart slides found'
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array(
                'title',
                'editor',
            ),
           
       ));
}

if ( function_exists( 'add_image_size' ) ) {
    add_image_size( 'post_thumbnail', 52, 52, TRUE );
    add_image_size( 'post_main_thumbnail', 325, 290, TRUE );
    add_image_size( 'product_image', 294, 294, TRUE );
    add_image_size( 'product_small_image', 64, 64, TRUE );
}

add_action( 'wp_enqueue_scripts', 'remove_gridlist_styles', 30 );
function remove_gridlist_styles() {
    wp_dequeue_style( 'grid-list-button' );
    wp_dequeue_style( 'grid-list-layout' );
}
