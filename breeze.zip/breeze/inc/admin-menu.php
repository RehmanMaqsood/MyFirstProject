<?php

add_action('admin_menu', 'contact_us');

function contact_us() {

add_theme_page('Breeze Settings', 'Breeze Settings', 'administrator', 
'breeze-options', 'breeze_settings_page');

add_action( 'admin_init', 'register_breezesettings' );
}


function register_breezesettings() {
register_setting( 'breeze-settings-group', 'breeze_phone' );
register_setting( 'breeze-settings-group', 'breeze_address' );
register_setting( 'breeze-settings-group', 'breeze_email' );
register_setting( 'breeze-settings-group', 'breeze_copyright' );
register_setting( 'breeze-settings-group', 'breeze_facebook' );
register_setting( 'breeze-settings-group', 'breeze_twitter' );
register_setting( 'breeze-settings-group', 'breeze_google' );
}

function breeze_settings_page() {
?>
<div class="wrap">
<h2>Breeze Options</h2>

<form method="post" action="options.php">

<?php settings_fields('breeze-settings-group'); ?>
    
<h3>General settings</h3>
<table class="form-table">
<tr valign="top">
    <th scope="row">Phone</th>
    <td><textarea name="breeze_phone"><?php echo get_option('breeze_phone'); ?></textarea></td>
</tr>

<tr valign="top">
    <th scope="row">Address</th>
    <td><textarea name="breeze_address"><?php echo get_option('breeze_address'); ?></textarea></td>
</tr>

<tr valign="top">
    <th scope="row">Email</th>
    <td><textarea name="breeze_email"><?php echo get_option('breeze_email'); ?></textarea></td>
</tr>

<tr valign="top">
    <th scope="row">Copyright</th>
    <td><textarea name="breeze_copyright"><?php echo get_option('breeze_copyright'); ?></textarea></td>
</tr>
</table>
    
<h3>Social Links</h3>
<table class="form-table">
<tr valign="top">
    <th scope="row">Link Facebook</th>
    <td><textarea name="breeze_facebook"><?php echo get_option('breeze_facebook'); ?></textarea></td>
</tr>

<tr valign="top">
    <th scope="row">Link Twitter</th>
    <td><textarea name="breeze_twitter"><?php echo get_option('breeze_twitter'); ?></textarea></td>
</tr>

<tr valign="top">
    <th scope="row">Link Google</th>
    <td><textarea name="breeze_google"><?php echo get_option('breeze_google'); ?></textarea></td>
</tr>

</table>


<p class="submit">
    <input type="submit" class="button-primary" value="<?php _e('Save Changes', 'breeze') ?>" />
</p>

</form>
</div>

<?php } ?>