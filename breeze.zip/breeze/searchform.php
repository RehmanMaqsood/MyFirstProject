<form method="get" class="search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
        <input type="text" class="entry_form" name="s" placeholder="<?php esc_attr_e( 'Search', 'breeze' ); ?>" />
</form>
